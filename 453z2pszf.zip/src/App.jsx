import React, { useState, useMemo } from 'react';
import './App.css';

// Mock Data for College Clubs
const CLUBS_DATA = [
  {
    id: 1,
    name: "Hyperion Coding Guild",
    category: "coding",
    tagline: "Building tomorrow's software, today.",
    description: "A collaborative hub for developers, open-source contributors, and competitive programmers. We host weekly hackathons, code reviews, and build real-world web apps.",
    memberCount: 142,
    meetingTime: "Tuesdays at 6:00 PM",
    room: "Engineering Block, Lab 404",
    lead: "Alex Rivera",
    accentColor: "#3b82f6"
  },
  {
    id: 2,
    name: "Apex Athletics & Soccer Club",
    category: "sports",
    tagline: "Chasing goals on and off the pitch.",
    description: "Whether you are a seasoned player or a beginner, join us for competitive tournaments, casual scrimmages, and intense fitness drills every weekend.",
    memberCount: 95,
    meetingTime: "Saturdays at 7:00 AM",
    room: "Main Sports Arena",
    lead: "Jordan Malik",
    accentColor: "#10b981"
  },
  {
    id: 3,
    name: "Avant-Garde Canvas Guild",
    category: "arts",
    tagline: "Expressing the unseen through raw media.",
    description: "An inclusive space exploring digital art, traditional painting, graffiti culture, and sculpting. We organize annual campus gallery exhibitions and mural projects.",
    memberCount: 68,
    meetingTime: "Thursdays at 4:30 PM",
    room: "Fine Arts Studio B",
    lead: "Chloe Chen",
    accentColor: "#ec4899"
  },
  {
    id: 4,
    name: "The Launchpad Incubator",
    category: "entrepreneurship",
    tagline: "Turning dorm-room sketches into funded startups.",
    description: "Connect with venture capitalists, perfect your pitch deck, and participate in our flagship $10k seed fund competition. Your entrepreneurial journey starts here.",
    memberCount: 110,
    meetingTime: "Mondays at 5:30 PM",
    room: "Innovation Hub, Rm 101",
    lead: "Marcus Vance",
    accentColor: "#f59e0b"
  },
  {
    id: 5,
    name: "Quantum AI Alliance",
    category: "coding",
    tagline: "Exploring deep learning and machine intelligence.",
    description: "Diving deep into neural networks, computer vision, and large language models. Members work closely on research papers and algorithmic kaggle tracks.",
    memberCount: 84,
    meetingTime: "Wednesdays at 7:00 PM",
    room: "Tech Center, Hall A",
    lead: "Sarah Jenkins",
    accentColor: "#6366f1"
  },
  {
    id: 6,
    name: "Vanguard Track & Trail",
    category: "sports",
    tagline: "Pushing physical limits across wild terrain.",
    description: "Dedicated to long-distance running, trail blazing, and adventure hiking. Weekly outdoor tracks followed by endurance optimization training.",
    memberCount: 52,
    meetingTime: "Fridays at 6:00 AM",
    room: "Campus Trailhead Gate",
    lead: "Ethan Hunt",
    accentColor: "#14b8a6"
  }
];

// Reusable Club Card Component
function ClubCard({ club, onSelect }) {
  const categoryEmojis = {
    coding: "💻",
    sports: "⚽",
    arts: "🎨",
    entrepreneurship: "🚀"
  };

  return (
    <div className="club-card" onClick={() => onSelect(club)}>

      <div
        className="card-badge"
        style={{
          backgroundColor: `${club.accentColor}15`,
          color: club.accentColor
        }}
      >
        <span className="badge-emoji">
          {categoryEmojis[club.category]}
        </span>

        <span className="badge-text">
          {club.category}
        </span>
      </div>

      <h3 className="card-title">
        {club.name}
      </h3>

      <p className="card-tagline">
        {club.tagline}
      </p>

      <div className="card-footer">

        <span className="member-indicator">
          👥 {club.memberCount} Members
        </span>

        <button
          className="view-btn"
          style={{ '--hover-color': club.accentColor }}
        >
          Explore →
        </button>

      </div>
    </div>
  );
}

export default function App() {

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedClub, setSelectedClub] = useState(null);

  // Added only for submission notification
  const [showNotification, setShowNotification] = useState(false);

  const categories = [
    "all",
    "coding",
    "sports",
    "arts",
    "entrepreneurship"
  ];

  const filteredClubs = useMemo(() => {

    return CLUBS_DATA.filter((club) => {

      const matchesSearch =
        club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        club.tagline.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory =
        selectedCategory === "all" ||
        club.category === selectedCategory;

      return matchesSearch && matchesCategory;

    });

  }, [searchTerm, selectedCategory]);

  // Added only for submission notification
  const handleSubmit = () => {

    setShowNotification(true);

    setTimeout(() => {
      setShowNotification(false);
    }, 3000);

  };

  return (

    <div className="portal-container">

      {/* Submission Notification */}
      {showNotification && (
        <div
          style={{
            position: "fixed",
            top: "20px",
            right: "20px",
            zIndex: 9999,
            padding: "15px 20px",
            backgroundColor: "white",
            color: "black",
            border: "1px solid #ccc",
            borderRadius: "8px",
            boxShadow: "0 4px 15px rgba(0,0,0,0.3)"
          }}
        >
          ✓ Response submitted successfully!
        </div>
      )}

      {/* Header */}
      <header className="portal-header">

        <div className="brand-group">

          <div className="brand-logo">
            ⚔️
          </div>

          <div>
            <h1>Campus Club Explorer</h1>
            <p>University Club Directory</p>
          </div>

        </div>

        <div className="controls-bar">

          <div className="search-wrapper">

            <span className="search-icon">
              🔍
            </span>

            <input
              type="text"
              placeholder="Search specific clubs or keywords..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />

          </div>

          <div className="filter-group">

            {categories.map((cat) => (

              <button
                key={cat}
                className={`filter-tab ${
                  selectedCategory === cat ? 'active' : ''
                }`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>

            ))}

          </div>

        </div>

      </header>

      {/* Main Content */}
      <main className="portal-content">

        {filteredClubs.length > 0 ? (

          <div className="clubs-grid">

            {filteredClubs.map((club) => (

              <ClubCard
                key={club.id}
                club={club}
                onSelect={setSelectedClub}
              />

            ))}

          </div>

        ) : (

          <div className="empty-state">

            <div className="empty-icon">
              📂
            </div>

            <h3>
              No Active Guilds Found
            </h3>

            <p>
              We couldn't find matches for "{searchTerm}".
              Try exploring other interest tags.
            </p>

            <button
              className="reset-btn"
              onClick={() => {
                setSearchTerm("");
                setSelectedCategory("all");
              }}
            >
              Clear All Filters
            </button>

          </div>

        )}

      </main>

      {/* Club Details Drawer */}
      {selectedClub && (

        <div
          className="drawer-overlay"
          onClick={() => setSelectedClub(null)}
        >

          <div
            className="drawer-panel"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="close-panel-btn"
              onClick={() => setSelectedClub(null)}
            >
              ✕
            </button>

            <div
              className="drawer-hero"
              style={{
                background: `linear-gradient(
                  135deg,
                  ${selectedClub.accentColor}dd,
                  ${selectedClub.accentColor}
                )`
              }}
            >

              <span className="drawer-category">
                {selectedClub.category.toUpperCase()}
              </span>

              <h2>
                {selectedClub.name}
              </h2>

              <p>
                "{selectedClub.tagline}"
              </p>

            </div>

            <div className="drawer-body">

              <div className="section">

                <h4>
                  About The Club
                </h4>

                <p className="desc-text">
                  {selectedClub.description}
                </p>

              </div>

              <div className="info-meta-grid">

                <div className="meta-item">

                  <span className="meta-label">
                    Club President
                  </span>

                  <span className="meta-value">
                    {selectedClub.lead}
                  </span>

                </div>

                <div className="meta-item">

                  <span className="meta-label">
                    Active Roster
                  </span>

                  <span className="meta-value">
                    {selectedClub.memberCount} Students
                  </span>

                </div>

                <div className="meta-item">

                  <span className="meta-label">
                    Assembly Time
                  </span>

                  <span className="meta-value">
                    {selectedClub.meetingTime}
                  </span>

                </div>

                <div className="meta-item">

                  <span className="meta-label">
                    Headquarters Location
                  </span>

                  <span className="meta-value">
                    {selectedClub.room}
                  </span>

                </div>

              </div>

              {/* Submit Membership Request */}
              <button
                className="action-join-btn"
                style={{
                  backgroundColor: selectedClub.accentColor
                }}
                onClick={handleSubmit}
              >
                Submit Membership Request
              </button>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}